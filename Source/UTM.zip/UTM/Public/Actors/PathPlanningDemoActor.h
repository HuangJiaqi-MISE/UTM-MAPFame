#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Planning/GridMap3D.h"
#include "Planning/AStarPlanner.h"
#include "Planning/DStarLitePlanner.h"
#include "Planning/PathPlannerBase.h"
#include "Planning/PlanningInputValidator.h"
#include "Planning/DroneMissionTypes.h"
#include "Planning/TemporalNoFlyZoneTypes.h"
#include "PathPlanningDemoActor.generated.h"

class USceneComponent;
class ADroneActor;
class AMissionMarkerActor;
class ANoFlyZoneMarkerActor;
class AStaticMeshActor;

UENUM(BlueprintType)
enum class EPlannerType : uint8
{
    AStar      UMETA(DisplayName = "A*"),
    SIPP       UMETA(DisplayName = "SIPP"),
    DStarLite  UMETA(DisplayName = "D* Lite"),
    JPS        UMETA(DisplayName = "JPS"),
    CBS        UMETA(DisplayName = "CBS"),
    ECBS       UMETA(DisplayName = "ECBS"),
    PBS        UMETA(DisplayName = "PBS"),
    LaCAM      UMETA(DisplayName = "LaCAM"),
    LaCAMUTM   UMETA(DisplayName = "LaCAM-UTM")
};

/*
ģʽ A��ȫ������ӳ�,�ʺϿ��ٿ�Ч����
ģʽ B��ָ�� agent �ӳ�,����ֻ�� Mission 2 �ӳ�,����ȷ�۲쵥��ִ���쳣����ƻ����� schedule��
ģʽ C��ָ�� timestep �ӳ�,������ Agent 2 �� t=4, 7, 8 ԭ�صȴ�,��ʵ��ɸ��֡��ɽ��͡�
*/
UENUM(BlueprintType)
enum class EExecutionDelayMode : uint8
{
    RandomGlobal        UMETA(DisplayName = "Random Global"),
    PerAgentProbability UMETA(DisplayName = "Per-Agent Probability"),
    ScriptedTimesteps   UMETA(DisplayName = "Scripted Timesteps")
};

UENUM(BlueprintType)
enum class ECityLayoutType : uint8
{
    Manhattan,
    Residential,
    Industrial,
    Mixed
};

// ���ڼ�¼��������Ĺ滮ͳ������
USTRUCT(BlueprintType)
struct FSingleMissionTimingStats
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    int32 MissionId = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    bool bSuccess = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    int32 PathPointCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    double SolveTimeMs = 0.0;
};

// ���ڼ�¼����滮���̵�ͳ�����ݣ�����ÿ�������ͳ��
USTRUCT(BlueprintType)
struct FPlanningTimingStats
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    FString PlannerName;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    bool bMultiAgent = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    bool bSuccess = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    int32 MissionCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    double TotalTimeMs = 0.0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    double BuildGridTimeMs = 0.0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    double InputPreparationTimeMs = 0.0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    double SolveTimeMs = 0.0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    double PostProcessTimeMs = 0.0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
    TArray<FSingleMissionTimingStats> MissionStats;
};

USTRUCT(BlueprintType)
struct FNoFlyZonePathViolation
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 MissionId = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 ZoneId = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 TimeStep = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    FIntVector Cell = FIntVector::ZeroValue;
};

USTRUCT(BlueprintType)
struct FNoFlyZonePathValidationSummary
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 CheckedMissionCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 CheckedPointCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 ViolatingMissionCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    int32 TotalViolationCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
    TArray<FNoFlyZonePathViolation> Violations;
};

USTRUCT(BlueprintType)
struct FExecutionAgentState
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    int32 MissionId = INDEX_NONE;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    TObjectPtr<ADroneActor> Drone = nullptr;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    TArray<FIntVector> PlannedCells;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    TArray<FIntVector> ActualCells;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    int32 ExecutedPlanIndex = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    int32 TotalDelaySteps = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    bool bFinished = false;

    FIntVector DisplayFromCell = FIntVector::ZeroValue;
    FIntVector DisplayToCell = FIntVector::ZeroValue;
};

USTRUCT(BlueprintType)
struct FExecutionConflict
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    int32 TimeStep = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    int32 AgentA = INDEX_NONE;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    int32 AgentB = INDEX_NONE;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    bool bIsEdgeConflict = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    FIntVector Cell = FIntVector::ZeroValue;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    FIntVector FromA = FIntVector::ZeroValue;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    FIntVector ToA = FIntVector::ZeroValue;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    FIntVector FromB = FIntVector::ZeroValue;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution")
    FIntVector ToB = FIntVector::ZeroValue;
};

USTRUCT(BlueprintType)
struct FAgentDelayConfig
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    int32 MissionId = INDEX_NONE;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float DelayProbability = 0.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    TArray<int32> ForcedDelaySteps;
};

USTRUCT(BlueprintType)
struct FExecutionAgentSummary
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 MissionId = INDEX_NONE;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 PlannedCellCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 ActualCellCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 PlannedMakespan = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 ActualMakespan = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 TotalDelaySteps = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 FirstMismatchTime = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    bool bReachedGoal = false;
};

USTRUCT(BlueprintType)
struct FExecutionSummary
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 AgentCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 CompletedAgentCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 PlannedMakespan = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 ActualMakespan = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 TotalDelaySteps = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 VertexConflictCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 EdgeConflictCount = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    int32 FirstConflictTime = -1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    TArray<FExecutionAgentSummary> AgentSummaries;
};


UCLASS()
class UTM_API APathPlanningDemoActor : public AActor
{
    GENERATED_BODY()

public:
    APathPlanningDemoActor();

protected:
    virtual void BeginPlay() override;

public:
    virtual void Tick(float DeltaTime) override;

private:
    bool ParseTaggedId(AActor* Actor, const FString& Prefix, int32& OutId) const;

    void CollectStartGoalPairs(
        TArray<int32>& OutIds,
        TMap<int32, TObjectPtr<AActor>>& OutStarts,
        TMap<int32, TObjectPtr<AActor>>& OutGoals) const;

    void LogPathCoordinates(const TArray<FVector>& InPath, int32 Id, const TCHAR* Label) const;
    void DrawPathDebug(const TArray<FVector>& InPath, const FColor& Color) const;
    FColor GetDebugColorById(int32 Id) const;
    bool IsCellInsideNoFlyZoneAtTime(const FIntVector& Cell, int32 TimeStep, const FTemporalNoFlyZoneConfig& ZoneConfig) const;
    void ValidatePathAgainstNoFlyZones(int32 MissionId, const TArray<FVector>& PathPoints, FNoFlyZonePathValidationSummary& InOutSummary) const;
    void LogNoFlyZonePathValidationSummary(const FNoFlyZonePathValidationSummary& Summary) const;
    void CachePlannedPath(int32 MissionId, const TArray<FVector>& PathPoints);
    void ResetPathValidationCache();

private:
    TArray<FIntVector> BuildCellPathFromWorldPath(const TArray<FVector>& PathPoints) const;
    FIntVector GetCellAtTime(const TArray<FIntVector>& Cells, int32 TimeStep) const;

    void ResetExecutionCache();
    void InitializeExecutionStates();
    void AdvanceExecutionOneStep();
    void UpdateExecutionVisuals(float Alpha);
    bool ShouldDelayThisStep(const FExecutionAgentState& State, int32 TimeStep);
    void DetectExecutionConflictsAtStep(int32 TimeStep);
    void DrawExecutionDebugForState(const FExecutionAgentState& State, int32 TimeStep) const;
    const FAgentDelayConfig* FindAgentDelayConfig(int32 MissionId) const;
    bool IsForcedDelayStep(const FExecutionAgentState& State, int32 TimeStep) const;
    int32 ComputeFirstMismatchTime(const FExecutionAgentState& State) const;
    void BuildExecutionSummary();
    void LogExecutionSummary() const;

private:
    FGridMap3D GridMap;
    FPlanningInputValidator InputValidator;
    TMap<int32, TArray<FVector>> LastPlannedPathsByMission;

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planning")
    bool bAutoRunPlanningOnBeginPlay = false;

    UFUNCTION(BlueprintCallable, Category = "Planning")
    void RunPlanning();

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Validation")
    void ValidateLastPlannedPathsAgainstNoFlyZones();



    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    TObjectPtr<USceneComponent> SceneRoot;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    FVector GridOrigin = FVector(0.f, 0.f, 0.f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    FIntVector GridDim = FIntVector(100, 100, 10);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    float CellSize = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid Debug")
    bool bDrawOccupiedCells = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid Debug")
    bool bDrawFreeCells = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid Debug")
    float DebugDrawTime = 10.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Path Debug")
    bool bDrawPaths = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Path Debug")
    bool bDrawPathPoints = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Path Debug")
    float PathDrawTime = 20.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Path Debug")
    float PathLineThickness = 5.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Path Debug")
    bool bLogPathCoordinates = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Validation")
    bool bValidatePathsAgainstNoFlyZones = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Validation", meta = (ClampMin = "0"))
    int32 MaxLoggedNoFlyZoneViolations = 20;

    // ���˻���ͼ�Զ�����
protected:
    ADroneActor* SpawnDroneForPath(const TArray<FVector>& PathPoints, int32 PairId);

private:
    TArray<TObjectPtr<ADroneActor>> SpawnedDrones;

    TMap<int32, TObjectPtr<ADroneActor>> SpawnedDroneByMissionId;
    TMap<int32, TArray<FIntVector>> PlannedCellPathsByMission;
    TMap<int32, FExecutionAgentState> ExecutionStates;
    TArray<FExecutionConflict> ExecutionConflicts;

    FRandomStream ExecutionRandom;
    bool bExecutionRunning = false;
    int32 CurrentExecutionTimeStep = 0;
    float ExecutionAccumulator = 0.f;

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drone Spawn")
    TSubclassOf<ADroneActor> DroneClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drone Spawn")
    bool bAutoSpawnDrones = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Drone Spawn", meta = (ClampMin = "0.01"))
    float CBSStepDuration = 0.333f;

    // ִ��������
public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    bool bUseCentralizedExecution = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    EExecutionDelayMode DelayMode = EExecutionDelayMode::RandomGlobal;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    TArray<FAgentDelayConfig> AgentDelayConfigs;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    bool bLogExecutionSummary = true;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Execution Summary")
    FExecutionSummary LastExecutionSummary;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution", meta = (ClampMin = "0.0", ClampMax = "1.0"))
    float StepDelayProbability = 0.20f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution")
    int32 ExecutionRandomSeed = 12345;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution Debug")
    bool bDrawExecutionCells = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution Debug")
    bool bDrawExecutionText = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Execution Debug")
    float ExecutionDebugDrawTime = 0.4f;

    // ���˻�����+�������
    // �����ʹ�� MissionConfigs����ӳ������ֶ����� Start_i / Goal_i ��ָ���������������յ�
protected:
    bool ProcessMissionConfigs();
    bool ProcessStartGoalPairsMultiAgent();
    bool ProcessMissionConfigsMultiAgent();
    bool PlanMultiAgentMissions(const TArray<FDroneMissionConfig>& Missions, TMap<int32, TArray<FVector>>& OutPaths) const;
    bool IsMultiAgentPlannerType() const;
public:
    /*
    false�������ó������ֶ����õ� Start_i / Goal_i
    true������ MissionConfigs �ӽ���ֱ������
    */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Config")
    bool bUseMissionConfigs = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Config")
    TArray<FDroneMissionConfig> MissionConfigs;

    // �㷨ѡ��
private:
    FString GetPlannerTypeName() const;
    TUniquePtr<IPathPlannerBase> CreatePlannerByType() const;
public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planner")
    EPlannerType PlannerType = EPlannerType::AStar;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planner", meta = (ClampMin = "1.0"))
    float ECBSSuboptimalityBound = 1.5f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planner", meta = (ClampMin = "1"))
    int32 LaCAMTimeLimitMs = 8000;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planner")
    int32 LaCAMRandomSeed = 12345;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planner")
    bool bLaCAMAnytime = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Planner", meta = (ClampMin = "0"))
    int32 LaCAMVerboseLevel = 0;


    // UI������㡢�յ�����
private:
    bool TryGenerateSingleMission(
        FRandomStream& RandomStream,
        int32 MissionId,
        TSet<FIntVector>& UsedStarts,
        TSet<FIntVector>& UsedGoals,
        FDroneMissionConfig& OutMission) const;

    void GetMissionMarkerActors(TArray<AMissionMarkerActor*>& OutMarkers) const;
    void GetNoFlyZoneMarkerActors(TArray<ANoFlyZoneMarkerActor*>& OutMarkers) const;
public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    TSubclassOf<AMissionMarkerActor> MissionMarkerClass;

    // �Ǵ���ʾ/�༭��;�ĸ߶�ƫ��,marker �ḡ�ø��ߣ����ÿ���
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    float MarkerZOffset = 30.f;

    // Generate Random Missions ��������
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    int32 RandomMissionCount = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    int32 RandomSeed = 12345;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    int32 MinStartGoalCellDistance = 3;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    bool bAllowDuplicateStartCells = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mission Editor")
    bool bAllowDuplicateGoalCells = false;

    UFUNCTION(BlueprintCallable, Category = "Mission Editor")
    void EditorBuildGridForMissionEditing();

    UFUNCTION(BlueprintCallable, Category = "Mission Editor")
    void EditorGenerateRandomMissionConfigs();

    UFUNCTION(BlueprintCallable, Category = "Mission Editor")
    void EditorSpawnMissionMarkers();

    UFUNCTION(BlueprintCallable, Category = "Mission Editor")
    void EditorClearMissionMarkers();

    UFUNCTION(BlueprintCallable, Category = "Mission Editor")
    void EditorValidateMissionConfigs();

    UFUNCTION(BlueprintCallable, Category = "Mission Editor")
    void EditorReadMissionMarkersToConfigs();

	// UI�༭��ʱ����������
    // ���浱ǰ���н���������
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor")
    TArray<FTemporalNoFlyZoneConfig> NoFlyZoneConfigs;

    // ָ�����������ɽ���������ʱ���ĸ���ͼ��
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor")
    TSubclassOf<ANoFlyZoneMarkerActor> NoFlyZoneMarkerClass;

    // Ĭ�����ɶ��Ľ�����,��λ�� cell դ�����꣬������������
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "1"))
    int32 DefaultNoFlyZoneSizeCells = 3;

    // Ĭ��ʱ�䴰������ã�����Ĭ�� 10���ͻ��������ƣ�StartTimeStep = 0    EndTimeStep = 9
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "1"))
    int32 DefaultNoFlyZoneDuration = 10;

    // һ��������ɶ��ٸ�������
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "0"))
    int32 RandomNoFlyZoneCount = 5;

    // ͬ�������� + ͬ���Ĳ����������ϻ�����ͬһ�������������ʺ����ɸ���ʵ��
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor")
    int32 NoFlyZoneRandomSeed = 12345;

    // �������������Сƽ��ߴ硣������Ҫ���� XY �ߴ��½硣
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "1"))
    int32 RandomNoFlyZoneMinSizeCells = 2;

    // ��������������ƽ��ߴ硣������Ҫ���� XY �ߴ��Ͻ硣������MinSize = 2   MaxSize = 6  ��ʾ�������� X / Y �ߴ���� 2 �� 6 �� cell ֮�������
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "1"))
    int32 RandomNoFlyZoneMaxSizeCells = 6;

    // ������������ĸ�ʱ�䲽��ʼ��Ч
	// ������MinStartTimeStep = 0   MaxStartTimeStep = 50  ��ʾ�������Ŀ�ʼʱ����� 0 �� 50 ��ʱ�䲽֮�������
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "0"))
    int32 RandomNoFlyZoneMinStartTimeStep = 0;

    // �������������ĸ�ʱ�䲽��ʼ��Ч
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "0"))
    int32 RandomNoFlyZoneMaxStartTimeStep = 5;

    // ������ʱ�䴰����̳���ʱ��
    // ������ MinDuration = 10   MaxDuration = 30  ��ʾÿ������������� 10 �� 30 ��ʱ�䲽��
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "1"))
    int32 RandomNoFlyZoneMinDuration = 5;

    // ������ʱ�䴰�������ʱ��
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "No-Fly Zone Editor", meta = (ClampMin = "1"))
    int32 RandomNoFlyZoneMaxDuration = 15;

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Editor")
    void EditorGenerateRandomNoFlyZoneConfigs();

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Editor")
    void EditorAddNoFlyZoneConfig();

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Editor")
    void EditorSpawnNoFlyZoneMarkers();

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Editor")
    void EditorClearNoFlyZoneMarkers();

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Editor")
    void EditorReadNoFlyZoneMarkersToConfigs();

    UFUNCTION(BlueprintCallable, Category = "No-Fly Zone Editor")
    void EditorValidateNoFlyZones();





// ��̬�ϰ���������༭
private:
    void SpawnCityBuilding(const FVector& Center, const FVector& Extent);
    void GenerateCityLayout_Manhattan(FRandomStream& RandomStream);
    void GenerateCityLayout_Residential(FRandomStream& RandomStream);
    void GenerateCityLayout_Industrial(FRandomStream& RandomStream);
    void GenerateCityLayout_Mixed(FRandomStream& RandomStream);


public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator")
    int32 CitySeed = 12345;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "1"))
    int32 CityBlocksX = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "1"))
    int32 CityBlocksY = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float CityBlockSize = 800.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "0.0"))
    float CityRoadWidth = 200.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float BuildingWidthMin = 200.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float BuildingWidthMax = 500.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float BuildingDepthMin = 200.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float BuildingDepthMax = 500.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float BuildingHeightMin = 600.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator", meta = (ClampMin = "10.0"))
    float BuildingHeightMax = 1200.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City Generator")
    bool bAutoRebuildGridAfterCityGenerate = true;

    UFUNCTION(BlueprintCallable, Category = "City Generator")
    void EditorGenerateManhattanCity();

    UFUNCTION(BlueprintCallable, Category = "City Generator")
    void EditorGenerateResidentialDistrict();

    UFUNCTION(BlueprintCallable, Category = "City Generator")
    void EditorGenerateIndustrialPark();

    UFUNCTION(BlueprintCallable, Category = "City Generator")
    void EditorGenerateMixedUrbanArea();


    UFUNCTION(BlueprintCallable, Category = "City Generator")
    void EditorClearCityEnvironment();

//  ͳ�����ʱ�������
public:
        UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Timing")
        FPlanningTimingStats LastPlanningStats;

        UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "No-Fly Zone Validation")
        FNoFlyZonePathValidationSummary LastNoFlyZonePathValidation;

        UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Timing")
        bool bEnablePlanningTimeLog = true;

        UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "City")
        ECityLayoutType CityLayoutType = ECityLayoutType::Manhattan;

        bool ProcessStartGoalPairsSingleAgent(
            const TArray<int32>& Ids,
            const TMap<int32, TObjectPtr<AActor>>& Starts,
            const TMap<int32, TObjectPtr<AActor>>& Goals);

private:
    void ResetPlanningStats();
    void LogPlanningStatsSummary() const;
    FString GetCityLayoutTypeName() const;
};









